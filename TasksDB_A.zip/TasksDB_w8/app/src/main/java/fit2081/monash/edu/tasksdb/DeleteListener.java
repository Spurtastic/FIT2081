package fit2081.monash.edu.tasksdb;

public interface DeleteListener {
    void onClick(int id);
}
